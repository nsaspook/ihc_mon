/* 
 * File:   ihc_vector.h
 * Author: root
 *
 * Created on October 22, 2017, 4:25 PM
 */

#ifndef IHC_VECTOR_H
#define	IHC_VECTOR_H

#ifdef	__cplusplus
extern "C" {
#endif
#include <xc.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "ibsmon.h"

#ifdef	__cplusplus
}
#endif

#endif	/* IHC_VECTOR_H */

